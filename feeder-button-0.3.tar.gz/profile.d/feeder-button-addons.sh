export PATH=${PATH}:/usr/local/addons/feeder-button/bin
export TERM=xterm
